<?php
    use App\Http\Controllers\IndexController;
?>



<?php $__env->startSection('content'); ?>
    <div class="p-5 mb-4 bg-light rounded-3">
      <div class="container-fluid py-5">
        <h1 class="display-5 fw-bold">Aplicacion Practica jueves</h1>
        <p class="col-md-8 fs-4">Vamos a crear recursos con Id, nombre y precio
        
        <!--<a href="">about enlace 1</a>
        <a href="">about enlace 2</a>
        <a href="">about enlace 3</a>
        <a href="">about enlace 3</a>-->
        
        .</p>
        <p class="col-md-8 fs-4">
          <a href="<?php echo e(url('resource')); ?>">Link hacia recursos</a>.
        </p>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/aplicacionPractica/resources/views/index.blade.php ENDPATH**/ ?>