<?php $__env->startSection('content'); ?>
<h1><?php echo e($enterprise); ?></h1>

<table class="table table-striped">
    <thead>
        <tr>
            <th scope="col"># id</th>
            <th scope="col">name</th>
            <th scope="col">price</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>
                <?php echo e($resource['id']); ?>

            </td>
            <td>
                <?php echo e($resource['name']); ?>

            </td>
            <td>
                <?php echo e($resource['price']); ?>

            </td>
            <td>
                <a href="<?php echo e(url('resource')); ?>">volver</a>
            </td>
        </tr>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/aplicacionPractica/resources/views/resource/show.blade.php ENDPATH**/ ?>