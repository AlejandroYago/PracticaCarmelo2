<?php $__env->startSection('content'); ?>
<h1>Edita al gusto</h1>
<form action="<?php echo e(url('resource/' . $resource['id'])); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>
    <input value="<?php echo e(old('id', $resource['id'])); ?>" type="number" name="id" placeholder="#id positive integer" min="1" step="1" required hidden />
    <input value="<?php echo e(old('name', $resource['name'])); ?>" type="text" name="name" placeholder="Name of the resource" min-length="5" max-length="30" required />
    <input value="<?php echo e(old('price', $resource['price'])); ?>" type="number" name="price" placeholder="Introduce precio" min="0" step="0.01" required />
    <input type="submit" value="Edit"/>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/aplicacionPractica/resources/views/resource/edit.blade.php ENDPATH**/ ?>